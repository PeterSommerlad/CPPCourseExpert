#include "bounded_buffer_student_suite.h"
#include "cute.h"

//TODO: Add your own tests here

cute::suite make_suite_bounded_buffer_student_suite(){
	cute::suite s;
	return s;
}



