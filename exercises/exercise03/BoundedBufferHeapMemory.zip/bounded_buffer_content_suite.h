#ifndef BOUNDED_BUFFER_CONTENT_SUITE_H_
#define BOUNDED_BUFFER_CONTENT_SUITE_H_

#include "cute_suite.h"

extern cute::suite make_suite_bounded_buffer_content_suite();

#endif
