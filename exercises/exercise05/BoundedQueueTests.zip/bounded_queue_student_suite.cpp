#include "bounded_queue_student_suite.h"

#include "BoundedQueue.h"
#include "cute.h"

//TODO: Add your own tests here




cute::suite make_suite_bounded_queue_student_suite(){
	cute::suite s;
	return s;
}



