#ifndef BOUNDED_QUEUE_MULTI_THREADED_SUITE_H_
#define BOUNDED_QUEUE_MULTI_THREADED_SUITE_H_

#include "cute_suite.h"

extern cute::suite make_suite_bounded_queue_multi_threaded_suite();

#endif
