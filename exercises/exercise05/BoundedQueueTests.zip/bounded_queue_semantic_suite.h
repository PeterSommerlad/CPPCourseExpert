#ifndef BOUNDED_QUEUE_SEMANTIC_SUITE_H_
#define BOUNDED_QUEUE_SEMANTIC_SUITE_H_

#include "cute_suite.h"

extern cute::suite make_suite_bounded_queue_semantic_suite();

#endif
