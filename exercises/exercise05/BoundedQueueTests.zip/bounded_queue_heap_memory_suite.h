#ifndef BOUNDED_QUEUE_HEAP_MEMORY_SUITE_H_
#define BOUNDED_QUEUE_HEAP_MEMORY_SUITE_H_

#include "cute_suite.h"

extern cute::suite make_suite_bounded_queue_heap_memory_suite();


#endif
